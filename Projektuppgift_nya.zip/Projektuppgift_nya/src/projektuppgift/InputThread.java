/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projektuppgift;

import java.util.Observable;
import java.util.Observer;
import java.net.Socket;

/**
 *
 * @author lukasgu
 */
public class InputThread extends Observable implements Observer{
    
    private Socket mySocket;
    
    public InputThread(){
        
    }
    
    public void update( Observable o, Object arg){
    
    }
    
    public void run(){
        
    }
    
}
