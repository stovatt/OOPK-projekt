/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projektuppgift;

import java.util.Observable;

/**
 *
 * @author lukasgu
 */
public class KeyRequester extends Observable implements Runnable{
    
    public void run(){
        
    }
    
    public void sendKeyRequest(User recipient, String cryptotype){
        
    }
    
    public void notifyObservers( Object arg ){
        
    }
    
}
